#ifndef _MAX78615_PROG
#define _MAX78615_PROG

#include<stdint.h>

#define SYSSTATR (0x280 + (64 << 6)) // (System Status and Control Register) add 64<<6 to account for page offset
#define SPI_ERR         (1 << 23)           //         R 	0
#define SPI_CRC_ERR     (1 << 22)	        //         R 	0
#define SPI_CRC_ENABLE  (1 << 21)           //         R/W	0
#define CE_RUN          (1 << 20)	        //         R       '1' indicates that CE is running
#define FPI_MODE_ACTIVE (1 << 19)	        //         R/W	0  '1' indicates FPI mode
#define FLASH_BUSY      (1 << 18)	        //         R    0  '1' indicates busy
#define STOP            (1 << 17)	        //R SPI ONLY    0  Can only use this with SPI
#define XOSC_SEL        (1 << 16)	        //         R/W	0
#define XTL_RDY         (1 << 15)	        //         R	   0
#define XOSC_EN         (1 << 12)	        //         R/W  1
#define TESTMODE        ((1 << 11)|(1 << 10)|(1 << 9)) 
#define WDTMR	         (1 << 8)            //         R    0
#define CESTAT          0xFF                //         R/W  0

#define WDTPER (0x27A + (64 << 6)) //24 bit Watch Dog Timer

#define SYSFLASHCNTL (0x281 + (64 << 6))
#define MASS_ERASE 0x570000
#define PAGE_ERASE 0x007300

#define FLASH_PROGRAM_BEGIN 0   //first word of program space
#define FLASH_PROGRAM_END 0xBFF //last word of program space
#define FLASH_DATA_BEGIN  0xC00 //first word of data space
#define FLASH_DATA_END    0xFFF //last word of data space 

#define SPITO                (0x282 + (64 << 6))
#define SPI_TIME_OUT_DISABLE 0
#define SPI_TIME_OUT_1MS     0x1388

#define GET_PAGE(addr) (addr >> 6)
#define GET_ADDR(addr) (addr % 64)

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;

class MAX78615_PROGRAMMER
{
   public:
      MAX78615_PROGRAMMER(void);
      MAX78615_PROGRAMMER(int);      
            
      /*simply reconfigures the Arduino's SPI settings to
         -MSBFIRST
         -CLK_DIV16
         -MODE 3
         Call after another device uses SPI and changes its settings
      */
      void configure_spi();
      
      /*FUNCTION DESCRIPTION OF
      1. u8 read_registers(int address, u8 ret[], u8 words_to_read)
                                    ~AND~
      2. u8 write_registers(int address, u8 source[], u8 words_to_write);
      
      if 64 <= GET_PAGE(address) <= 75
         THEN assumes word width is 3 bytes.
         assumes each 24bit word is stored as 32bit unsigned ints.
         EX:
            READING:
            u32 ret_data[64];
            u8 bytes_read = read_registers(address, (u8 *) ret_data, 64);
            
            Then, each 24 bit word read from a register is stored into a 32
            bit integer array;
      
      else
         Assumes word width is 2 bytes. 
         EX:
            READING:            
            u16 ret_data[64];
            u8 bytes_read = read_registers(address, (u8 *)ret_data, 64);
      
      if the function address starts in a 2 byte word width page and crosses
      into a 3 byte word width page, it returns with the words it read/wrote.  
      
      RETURNS words read/written
      */     
      u8 read_registers(int address, u8 words[], u8 words_to_read, bool unlock = true);
      u8 write_registers(int address, u8 words[], u8 words_to_write, bool unlock = true);

      u32 read_register(int address, bool unlock = true);
      void write_register(int address, u32 a_word, bool unlock = true);
      
      void stop_ce();
      void reset_wdt();
      void unlock();
      void lock();
      void wait_for_flash();
      void mass_erase();
      bool verify_page(u8 page, volatile const u16 * source, bool unlock = true);
      void turn_off_SPI_time_out();

   private:
      int cs;
      void init(int cs);
      void unlock_lock(u8 * array);
};


#endif