#include <Arduino.h>
#include <SPI.h>
#include <stdint.h>
#include "MAX78615_PROGRAMMER.h"

#define FPI_UNLOCK_SIZE 9
#define FPI_LOCK_SIZE   9

//TODO: put in flash memory 
u8 _fpi_unlock[] = { 0x07, 0xF9, 0xE6, 0xBD, 0x8E, 0x16, 0x2F, 0x59, 0x26 };
u8 _fpi_lock[]   = { 0x07, 0xF9, 0xE6, 0   , 0   , 0   , 0   , 0   , 0    };

#define READ   0
#define WRITE (1 << 1)
#define FPI   (1 << 1)
#define TYPE  (1 << 0)
#define MISO  12
#define MOSI  11
#define CLK   13

#define _delay_62_5ns() __asm__("nop\n\t")
#define DELAY_MS(s) delay(s)
#define CS_LOW()        _delay_62_5ns(); _delay_62_5ns(); _delay_62_5ns(); _delay_62_5ns(); digitalWrite(cs, LOW); _delay_62_5ns(); _delay_62_5ns(); _delay_62_5ns(); _delay_62_5ns()
#define CS_HIGH()      _delay_62_5ns(); _delay_62_5ns(); digitalWrite(cs, HIGH)
#define SPI_XMIT(byte) SPI.transfer(byte)
 
u8   read_byte (void);
void write_byte(u8 byte);

void send_control_byte(u8 page, u8 word_addr, u8 additional_rw, u8 rw);
u8   get_word_width(u8 page);

MAX78615_PROGRAMMER::MAX78615_PROGRAMMER() 
{
   int default_chip_sel = 7;
   init(default_chip_sel); 
}  

MAX78615_PROGRAMMER::MAX78615_PROGRAMMER(int chip_sel) { init(chip_sel); }  
  
void MAX78615_PROGRAMMER::init(int cs)
{
   this->cs = cs;
   pinMode(cs, OUTPUT);
   configure_spi();
   SPI.begin();
   SPI.begin();
   CS_HIGH();   
}

void MAX78615_PROGRAMMER::configure_spi()
{
   SPI.setBitOrder(MSBFIRST);
   SPI.setClockDivider(SPI_CLOCK_DIV16);
   SPI.setDataMode(SPI_MODE3);
}

u8 read_byte() 
{
   u8 read = SPI_XMIT(0x00);
   return read;
}

void write_byte(u8 byte) 
{
   SPI_XMIT(byte); 
}

void MAX78615_PROGRAMMER::unlock_lock(u8 * array)
{
   CS_LOW();
   for (u8 i = 0; i < FPI_UNLOCK_SIZE; i++)
   {
      write_byte(array[i]);
   }
   CS_HIGH();
}

void MAX78615_PROGRAMMER::unlock() { unlock_lock(_fpi_unlock); }

void MAX78615_PROGRAMMER::lock()   { unlock_lock(_fpi_lock);   }

void send_control_byte(u8 page, u8 word_addr, u8 additional_rw, u8 rw)
{
  u8 tbuf[3];
  u8 NBRACC = additional_rw;
     NBRACC = (u8) (NBRACC << 2);
  
  tbuf[0] = NBRACC | FPI | TYPE;  
  tbuf[1] = (u8)((((page <= 75) && (page >= 64)) ? 0x80 : 0) + page);
  tbuf[2] = (u8)(word_addr << 2) | rw;
  
  write_byte(tbuf[0]);
  write_byte(tbuf[1]);
  write_byte(tbuf[2]);  
}
        
u8 get_word_width(u8 page)
{
   return ((page <= 75) && (page >= 64)) ? 3 : 2;
}
        
u8 MAX78615_PROGRAMMER::read_registers(int address, u8 ret[], u8 words_to_read, bool safe)
{
   u8 additional_rw, i, new_word_size;
   
   if (words_to_read < 1 || 64 < words_to_read ) return 0; 
   
   u8 page      = GET_PAGE(address);

   u8 word_addr = GET_ADDR(address);

   u8 word_size = get_word_width(page);   
   
   u8 word_size_for_array;
   
   if (word_size == 3) word_size_for_array = 4;
   else                word_size_for_array = 2;
   
   if (safe) unlock();
   
   CS_LOW();
   
   additional_rw = words_to_read - 1;
   
   send_control_byte(page, word_addr, additional_rw, READ);
   
   i = 0;
   
   while(words_to_read > 0)
   {      
      if (word_size == 3) { ret[2] = read_byte(); }
      ret[1] = read_byte();
      ret[0] = read_byte();
    
      ret += word_size_for_array;    
      words_to_read--;
      i++;
      
      //incrementing address only helps 
      //with keeping track of the page #
      address++;
      
      //if the word_size changes because 
      //we enter a new page, break
      new_word_size = get_word_width(GET_PAGE(address));
      
      if (new_word_size != word_size) break;
   }
   
   CS_HIGH();
   
   //return the words read
   return i;
}

u32 MAX78615_PROGRAMMER::read_register(int address, bool safe)
{
   u32 ret = 0;
   read_registers(address, (u8 *)&ret, 1, safe);
   return ret;
}

bool MAX78615_PROGRAMMER::verify_page(u8 page, volatile const u16 * source, bool safe)
{
   u16 read_word;
   
   u8 * read_word_addr = (u8 *) &read_word;

   u8 additional_rw, i, new_word_size;
   
   u8 words_to_read = 64;
   
   if (64 <= page && page <= 75) return false;
   
   if (safe) unlock();
   
   CS_LOW();
   
   additional_rw = words_to_read - 1;
   
   send_control_byte(page, 0, additional_rw, READ);
   
   i = 0;
   bool ret = true;
    
   while(words_to_read > 0)
   {     
      read_word_addr[1] = read_byte();
      read_word_addr[0] = read_byte();
    
      if (read_word != source[i]) 
      {
         //ret = false;      
         //Serial.print(i); Serial.print(". ");
         //Serial.print("read word: "); Serial.print(read_word, HEX);
         //Serial.print(" != source: ");
         //Serial.println(source[i], HEX);

         return false;
      }
      words_to_read--;
      i++;
   }
   
   CS_HIGH();
   return true;
   //return ret;
}

u8 MAX78615_PROGRAMMER::write_registers(int address, u8 ret[], u8 words_to_write, bool safe)
{
   u8 additional_rw, i, new_word_size;
   u8 * parts_of_word;
   
   if (words_to_write < 1 || 64 < words_to_write) return 0;
   
   u8 page      = GET_PAGE(address);

   u8 word_addr = GET_ADDR(address);

   u8 word_size = get_word_width(page);   
   
   u8 word_size_for_array;
   
   if (word_size == 3) word_size_for_array = 4;
   else                word_size_for_array = 2;

   if (safe) unlock();
   
   CS_LOW();
   
   additional_rw = words_to_write - 1;
      
   send_control_byte(page, word_addr, additional_rw, WRITE);
         
   i = 0;
   
   while(words_to_write > 0)
   {
      //assume little endian
      //assume that the LSB starts at the lower offset
      if (word_size == 3) { write_byte(ret[2]); }
      write_byte(ret[1]);
      write_byte(ret[0]);
            
      ret += word_size_for_array;      
      words_to_write--;
      i++;

      //incrementing address only helps 
      //with keeping track of the page #
      address++;
      
      //if the word_size changes because 
      //we enter a new page, break
      new_word_size = get_word_width(GET_PAGE(address));
      
      if (new_word_size != word_size) break;
   }
   CS_HIGH();
   //return bytes written
   return i;
}

void MAX78615_PROGRAMMER::write_register(int address, u32 a_word, bool safe)
{
   u8 words_to_write = 1;
   write_registers(address, (u8 *) &a_word, words_to_write, safe);
   return;
}
 
void MAX78615_PROGRAMMER::stop_ce()
{
   wait_for_flash();
   write_register(SYSSTATR, STOP | FPI_MODE_ACTIVE);
}

void MAX78615_PROGRAMMER::reset_wdt()
{
   wait_for_flash();
   write_register(WDTPER, 0x00FFFFFF);
}

void MAX78615_PROGRAMMER::wait_for_flash()
{
   u32 status;
   u8 trys = 0;
   do {
      status = read_register(SYSSTATR);
      if (status & FLASH_BUSY) { trys++; continue; }
      break;
   } while(trys < 255);
   
   if (trys == 255) Serial.println("Exceeded Trys");   
}

void MAX78615_PROGRAMMER::mass_erase()
{
   write_register(SYSFLASHCNTL, MASS_ERASE);
   DELAY_MS(10);
}

void MAX78615_PROGRAMMER::turn_off_SPI_time_out()
{
   u32 ret = read_register(SPITO);
   Serial.print(F("Got from SPITO: ")); Serial.println(ret, HEX);
   
   write_register(SPITO, SPI_TIME_OUT_DISABLE);
}